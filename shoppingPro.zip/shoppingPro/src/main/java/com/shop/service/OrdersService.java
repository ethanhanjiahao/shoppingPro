package com.shop.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shop.dao.impl.OrdersDao;
import com.shop.entity.Orders;

@Service
public class OrdersService {
	@Autowired
	OrdersDao<Orders> ordersDao;
	
	public void addOrders(Orders order) {
		ordersDao.save(order);
	}
	
	public void deleteOrders(Orders order) {
		ordersDao.delete(order);
	}
	
	public void updateOrders(Orders order) {
		ordersDao.update(order);
	}
	
	public Orders getOrderssById(int id) {
		return ordersDao.get(Orders.class, id);
	}
	
	public List<Orders> findOrdersByUserId(int userId) {
		String hql = "From Orders orders where orders.user.id=?";
		Object[] param = {userId};
		return ordersDao.find(hql, param);
	}

}
