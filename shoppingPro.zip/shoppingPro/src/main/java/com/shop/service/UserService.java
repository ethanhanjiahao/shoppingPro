package com.shop.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shop.dao.impl.UserDao;
import com.shop.entity.User;

@Service
public class UserService {
	@Autowired
	UserDao<User> userDao;
	
	public void addUser(User user) {
		userDao.save(user);
	}
	
	public void deleteUser(User user) {
		userDao.delete(user);
	}
	
	public void updateUser(User user) {
		userDao.update(user);
	}
	
	public User getUserByName(String userName) {
		String hql = "From User user where user.userName=?";
		Object[] param = {userName};
		User user = userDao.get(hql, param);
		return user;
	}
	
	public User doLogin(String username, String password) throws Exception{

		 String hql = "From User user where user.username=? and user.password=?";
		 Object[] param = {username,password};
		 User user = userDao.get(hql, param);		 
		 return user;
	}
}
