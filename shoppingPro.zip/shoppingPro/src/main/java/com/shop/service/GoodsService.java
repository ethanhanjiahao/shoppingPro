package com.shop.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shop.dao.impl.GoodsDao;
import com.shop.entity.Goods;

@Service
public class GoodsService {
	@Autowired
	GoodsDao<Goods> goodsDao;
	public void addGoods(Goods good) {
		goodsDao.save(good);
	}
	
	public void deleteGoods(Goods good) {
		goodsDao.delete(good);
	}
	
	public void updateGoods(Goods good) {
		goodsDao.update(good);
	}
	
	public Goods getGoodsById(int id) {
		return goodsDao.get(Goods.class, id);
	}
	
	public List<Goods> findGoodByGoodName(String name) {
		String hql = "From Goods goods where goods.name=?";
		Object[] param = {name};
		return goodsDao.find(hql, param);
	}
	
	//根据商品是否被购买搜索商品
	public List<Goods> findGoodByIfBuied(int ifBuied){
		String hql = "From Goods goods where goods.buied=?";
		Object[] param = {ifBuied};
		return goodsDao.find(hql, param);
	}
	
	//获取商品表中所有的商品
	public List<Goods> findAllGoods(){
		String hql = "From Goods as goods";
		return goodsDao.find(hql);
	}
}
