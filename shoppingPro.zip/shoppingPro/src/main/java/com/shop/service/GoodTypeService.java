package com.shop.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shop.dao.impl.GoodTypeDao;
import com.shop.entity.GoodType;

@Service
public class GoodTypeService {
	@Autowired
	GoodTypeDao<GoodType> goodTypeDao;
	
	public void addType(GoodType type) {
		goodTypeDao.save(type);
	}
	
	public void deleteType(GoodType type) {
		goodTypeDao.delete(type);
	}
	
	public void updateType(GoodType type) {
		goodTypeDao.update(type);
	}
	
	public GoodType getGoodTypeById(int id) {
		return goodTypeDao.get(GoodType.class, id);
	}
	
	public List<GoodType> findGoodTypeByTypeName(String typeName) {
		String hql = "From GoodType goodType where goodType.type=?";
		Object[] param = {typeName};
		return goodTypeDao.find(hql, param);
	}
}
