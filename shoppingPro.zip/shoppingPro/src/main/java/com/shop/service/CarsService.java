package com.shop.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shop.dao.impl.CarsDao;
import com.shop.entity.Cars;
import com.shop.entity.Goods;

@Service
public class CarsService {
	@Autowired
	CarsDao<Cars> carsDao;
	public void addCars(Cars car) {
		carsDao.save(car);
	}
	
	public void deleteCars(Cars car) {
		carsDao.delete(car);
	}
	
	public void updateCars(Cars car) {
		carsDao.update(car);
	}
	
	public Cars getCarsById(int id) {
		return carsDao.get(Cars.class, id);
	}
	
	//获取购物车中所有商品
	public List<Cars> findAllCars(){
		String hql = "From Cars as cars";
		return carsDao.find(hql);
	}
	
	//根据goodId查询购物车列表
	public List<Cars> getCarsByGoods(int goodId) {
		String hql = "From Cars as c where c.goods.id=?";
		Object[] param = {goodId};
		return  carsDao.find(hql, param);
	}
	
	//删除购物车中所有数据
	public void deleteAllCars() {
		String hql = "Delete From Cars as cars";
		carsDao.executeHql(hql);
	}
}
