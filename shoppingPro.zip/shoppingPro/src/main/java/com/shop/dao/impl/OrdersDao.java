package com.shop.dao.impl;

import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

@Repository("OrdersDao")
@Transactional
public class OrdersDao<T> extends BaseDaoImp<T> {

}
