package com.shop.dao.impl;

import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

@Repository("CarsDao")
@Transactional
public class CarsDao<T> extends BaseDaoImp<T> {

}
