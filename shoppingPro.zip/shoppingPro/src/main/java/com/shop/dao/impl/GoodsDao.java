package com.shop.dao.impl;

import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

@Repository("GoodsDao")
@Transactional
public class GoodsDao<T> extends BaseDaoImp<T> {

}
