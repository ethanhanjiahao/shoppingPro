package com.shop.dao.impl;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


@Repository("UserDao")
@Transactional
public class UserDao<T> extends BaseDaoImp<T>{
	
}
