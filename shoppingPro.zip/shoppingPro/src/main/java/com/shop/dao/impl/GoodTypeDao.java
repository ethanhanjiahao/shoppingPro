package com.shop.dao.impl;

import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

@Repository("GoodTypeDao")
@Transactional
public class GoodTypeDao<T> extends BaseDaoImp<T> {

}
