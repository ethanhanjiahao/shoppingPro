package com.shop.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


@Entity
@Table(name="goods")
public class Goods implements Serializable{
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="id")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	
	@Column(name="name")
	private String name;
	
	@Column(name="introduce")
	private String introduce;	//商品摘要
	
	@Column(name="picture")
	private String picture;
	
	@Column(name="price")
	private double price;
	
	@Column(name="text")
	private String text;		//商品正文
	
	@Column(name="buied")
	private int buied;	//是否被购买---0->未购买 1--->被购买
	
	@ManyToOne(targetEntity=GoodType.class)
	@JoinColumn(name="typeId")
	private GoodType goodType;
	

	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getIntroduce() {
		return introduce;
	}

	public void setIntroduce(String introduce) {
		this.introduce = introduce;
	}

	public String getPicture() {
		return picture;
	}

	public void setPicture(String picture) {
		this.picture = picture;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public GoodType getGoodType() {
		return goodType;
	}

	public void setGoodType(GoodType goodType) {
		this.goodType = goodType;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public int getIsBuied() {
		return buied;
	}

	public void setIsBuied(int isBuied) {
		this.buied = isBuied;
	}
}
