package com.shop.controller;

import java.util.List;

/**
 * 商品controller 主要包括商品发布，商品修改，商品购买等逻辑
 */
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;

import com.shop.entity.GoodType;
import com.shop.entity.Goods;
import com.shop.entity.User;
import com.shop.service.GoodsService;

import net.sf.json.JSONObject;

import com.shop.service.GoodTypeService;

@Controller
public class GoodsController {
	@Autowired
	GoodsService goodsService;
	@Autowired
	GoodTypeService goodTypeService;

	@RequestMapping("addGoods")
	public ModelAndView add(SessionStatus status) {
		return new ModelAndView("edit");
	}

	@RequestMapping(value = "addGoodToDB", method = { RequestMethod.POST, RequestMethod.GET })
	@ResponseBody
	public JSONObject addGoods(@RequestBody String object, HttpServletRequest request, HttpServletResponse response,
			ModelMap map) throws Exception {
		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");
		JSONObject ret = new JSONObject();
		JSONObject ob = JSONObject.fromObject(object);
		String goodName = (String) ob.get("goodName");
		String introduce = ob.getString("intro");
		String tmppic = ob.getString("pic");
		String picture = tmppic.substring(tmppic.trim().lastIndexOf("\\") + 1);
		String typeName = ob.getString("type");
		String price = ob.getString("price");
		String text = ob.getString("detail");
		List<GoodType> goodTypes = goodTypeService.findGoodTypeByTypeName(typeName);
		List<Goods> goods = goodsService.findGoodByGoodName(goodName);
		Goods good = new Goods();
		if (!goods.isEmpty()) {
			good = goods.get(0);
		}
		good.setGoodType(goodTypes.get(0));
		good.setIntroduce(introduce);
		good.setName(goodName);
		good.setPicture(picture);
		good.setPrice(Double.parseDouble(price));
		good.setText(text);
		// 不存在当前name的商品，可以进行加入商品列表操作
		if (goods.isEmpty()) {
			good.setIsBuied(0); // 新加入商品，代表商品未购买
			goodsService.addGoods(good);
			ret.put("status", "y");
			ret.put("url", "listPro");
			return ret;
		} else {
			// 更新当前产品
			goodsService.updateGoods(good);
			ret.put("status", "y");
			ret.put("url", "listPro");
			return ret;
		}
	}

	// 列出商品
	@RequestMapping("listPro")
	public ModelAndView listGoods(HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession(); // 获取当前session中的用户信息
		User user = (User) session.getAttribute("user");
		if (user == null) {
			return new ModelAndView("logine");
		}
		List<Goods> goods = goodsService.findAllGoods(); // 获取商品表中所有的商品
		ModelAndView modelAndView = new ModelAndView("list");
		modelAndView.addObject("productList", goods);
		return modelAndView;
	}

	// 列出商品
	@RequestMapping("listNotBuiedPro")
	public ModelAndView listNotBuiedPros(HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession(); // 获取当前session中的用户信息
		User user = (User) session.getAttribute("user");
		if (user == null) {
			return new ModelAndView("logine");
		}
		List<Goods> goods = goodsService.findGoodByIfBuied(0); // 获取商品表中未出售的商品
		ModelAndView modelAndView = new ModelAndView("unBuiedlist");
		modelAndView.addObject("productList", goods);
		return modelAndView;
	}

	// 详细商品
	@RequestMapping("viewDetail")
	public ModelAndView viewGoods(@RequestParam("id") int id, HttpServletRequest request,
			HttpServletResponse response) {
		HttpSession session = request.getSession(); // 获取当前session中的用户信息
		User user = (User) session.getAttribute("user");
		if (user == null) {
			return new ModelAndView("logine"); // 登陆
		}
		ModelAndView modelAndView = new ModelAndView("showDetails");
		Goods good = goodsService.getGoodsById(id);
		modelAndView.addObject("good", good);
		return modelAndView;
	}

	// 修改商品
	@RequestMapping("modify")
	public ModelAndView modifyGoods(@RequestParam("id") int id, HttpServletRequest request,
			HttpServletResponse response) {
		HttpSession session = request.getSession(); // 获取当前session中的用户信息
		User user = (User) session.getAttribute("user");
		if (user == null) {
			return new ModelAndView("logine"); // 登陆
		}
		ModelAndView modelAndView = new ModelAndView("edit");
		Goods good = goodsService.getGoodsById(id);
		modelAndView.addObject("good", good);
		return modelAndView;
	}

	// 删除未售出的商品
	@RequestMapping("delete")
	public ModelAndView deleteGoods( @RequestParam("id") int id,HttpServletRequest request,HttpServletResponse response) {
		HttpSession session = request.getSession(); // 获取当前session中的用户信息
		User user = (User) session.getAttribute("user");
		if (user == null) {
			return new ModelAndView("logine"); // 登陆
		}
		Goods good = goodsService.getGoodsById(id);
		goodsService.deleteGoods(good);
		ModelAndView modelAndView = new ModelAndView("list");
		return modelAndView;
	}
}
