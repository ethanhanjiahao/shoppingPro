package com.shop.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.shop.entity.Cars;
import com.shop.entity.Goods;
import com.shop.entity.Orders;
import com.shop.entity.User;
import com.shop.service.CarsService;
import com.shop.service.GoodsService;
import com.shop.service.OrdersService;
import com.shop.service.UserService;

@Controller
public class OrdersController {
	@Autowired
	OrdersService ordersService;
	@Autowired
	UserService userService;
	@Autowired
	GoodsService goodsService;
	@Autowired
	CarsService carsService;
	SimpleDateFormat sp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

	@RequestMapping(value = "addOrders", method = { RequestMethod.POST, RequestMethod.GET })
	@ResponseBody
	//public String addOrders(@RequestParam List<Cars> carsList, HttpServletRequest request, HttpServletResponse response,
	public void addOrders(HttpServletRequest request, HttpServletResponse response,
			ModelMap map) throws Exception {
		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");
		JSONObject ret = new JSONObject();
		HttpSession session = request.getSession(); // 获取当前session中的用户信息
		List<Cars> carsList = carsService.findAllCars(); // 获取购物车中所有的商品
		Cars car = new Cars();
		// 将购物车中的商品加入到购买订单列表
		for (int i = 0; i < carsList.size(); i++) {
			car = carsList.get(i);
			Goods good = car.getGoods();
			good.setIsBuied(1);  //代表已经将此商品卖了，已购买
			goodsService.updateGoods(good);	//更新good列表
			User user = (User) session.getAttribute("user");
			Orders order = new Orders();
			order.setBuyTime(sp.format(new Date()).toString());
			order.setGoods(good);
			order.setUser(user);
			order.setNum(car.getNumber());
			order.setPrice(good.getPrice());
			ordersService.addOrders(order);
		}
		carsService.deleteAllCars(); //删除购物车所有数据
		response.sendRedirect("listCars");
	}
	
	//列出财务清单（已购清单）
	@RequestMapping("listOrders")
	public ModelAndView listOrders(HttpServletRequest request,HttpServletResponse response) {
		HttpSession session = request.getSession(); //获取当前session中的用户信息
		User user = (User)session.getAttribute("user");
		//需要修改为判断登陆状态
		List<Orders> orders =  ordersService.findOrdersByUserId(user.getId());	//获取当前用户的购买清单
		System.out.println(orders.size());
		ModelAndView modelAndView = new ModelAndView("financial");
		modelAndView.addObject("orderList",orders);
		double money = 0;
		//计算所有财务的价钱
		for(int i=0;i<orders.size();i++) {
			Orders order = orders.get(i);
			money += order.getNum()*order.getPrice();
		}
		modelAndView.addObject("allMoney", money);
		return modelAndView;
	}
}
