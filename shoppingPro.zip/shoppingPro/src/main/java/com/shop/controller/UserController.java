package com.shop.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;

import com.shop.service.UserService;
import com.shop.utils.StringUtils;

import net.sf.json.JSONObject;

import com.shop.entity.User;

@Controller
public class UserController {
	@Autowired
	@Qualifier("userService")
	UserService userService;
	
	@RequestMapping("login")
	public ModelAndView login(SessionStatus status){
		return new ModelAndView("logine");
	}
	
	@RequestMapping("error")
	public ModelAndView error(SessionStatus status){
		return new ModelAndView("error");
	}

	@RequestMapping(value="doLogin",method={RequestMethod.POST, RequestMethod.GET})
	@ResponseBody
	public JSONObject doLogin(@RequestBody String object,HttpServletRequest request,HttpServletResponse response,ModelMap map) throws Exception{
		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");
		JSONObject ret = new JSONObject();
		System.out.println(object);
		JSONObject ob =  JSONObject.fromObject(object);
		String userName = (String) ob.get("userName");
		String pass = ob.getString("password");
		//用户名和密码不能为空不能为空
		if(userName == null || "".equals(userName)){
			ret.put("status", "n");
			//response.getWriter().write(ret.toString());
			return ret;
		}
		//获取数据库中用户和当前用户进行比较
		User user = userService.getUserByName(userName);
		if (user != null) {
			String password = user.getPassword();
			//使用MD5进行数据库密码加密验证
			String md5Password_real = StringUtils.getMD5Str(password,null);  
			if (md5Password_real.equals(pass)) {
				ret.put("status", "y");
				ret.put("url", "listPro");
				HttpSession session = request.getSession(true);
				session.setAttribute("user", user);
				return ret;
			}else {
				ret.put("status", "n");
				ret.put("info", "登录失败！");
				return ret;
			}
		} else {
			ret.put("status", "n");
			ret.put("info", "登录失败！");
			return ret;
		}
	}
	
	@RequestMapping(value="logout",method={RequestMethod.POST,RequestMethod.GET})
	public void logout(HttpServletRequest request, HttpServletResponse response) throws IOException{
		HttpSession session = request.getSession();
		session.removeAttribute("user");
		response.sendRedirect("login");
	}
}
