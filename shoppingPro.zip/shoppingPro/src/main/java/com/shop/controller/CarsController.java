package com.shop.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
/**
 * 购物车的controller 主要处理购物车结算、购物车展示、加入购物车等逻辑
 */
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.shop.entity.Cars;
import com.shop.entity.Goods;
import com.shop.entity.User;
import com.shop.service.CarsService;
import com.shop.service.GoodsService;

@Controller
public class CarsController {
	@Autowired
	CarsService carsService;
	@Autowired
	GoodsService goodsService;

	// 列出商品
	@RequestMapping("listCars")
	public ModelAndView listCars(HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession(); // 获取当前session中的用户信息
		User user = (User) session.getAttribute("user");
		if(user==null) {
			return new ModelAndView("logine");
		}
		List<Cars> cars = carsService.findAllCars(); // 获取购物车中所有的商品
		// System.out.println(goods.size());
		ModelAndView modelAndView = new ModelAndView("cars");
		modelAndView.addObject("carList", cars);
		return modelAndView;
	}

	@RequestMapping("addCars")
	@ResponseBody
	public void addCars(@RequestParam("id") int id, HttpServletRequest request, HttpServletResponse response) throws IOException {
		try {
			Goods good = goodsService.getGoodsById(id); // 获取当前商品
			List<Cars> cList = carsService.getCarsByGoods(id); // 判断当前购物车是否存在当前商品
			Cars car = new Cars();
			// 当前购物车不存在当前商品
			if (cList.isEmpty()) {
				car.setNumber(1);
				car.setGoods(good);
				carsService.addCars(car); // 新加商品至购物车
			} else {
				car = cList.get(0); // 获取当前购物车商品
				car.setNumber(car.getNumber() + 1);
				carsService.updateCars(car); // 更新当前购物车中的商品数量
			}
			response.sendRedirect("listPro");
		} catch (Exception e) {
			// TODO: handle exception
			response.sendRedirect("error");
		}
	}
}
