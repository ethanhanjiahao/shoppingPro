(function(w,d,u){
	var loginForm = util.get('loginForm');
	if(!loginForm){
		return;
	}
	var userName = loginForm['userName'];
	var password = loginForm['password'];
	var isSubmiting = false;
	var loading = new Loading();
	var page = {
		init:function(){
			loginForm.addEventListener('submit',function(e){
				if(!isSubmiting && this.check()){
					var value1 = userName.value;
					var value2 = md5(password.value);
					isSubmiting = true;
					loading.show();
					var requestData = {userName:value1,password:value2};
					$.ajax({
						url:'doLogin',
						type:'post',  
						dataType:'json',
						contentType:'application/json',
		                data:JSON.stringify(requestData),
						success:function(result){
							loading.hide();
							//location.href = 'l';
							//var obj = jQuery.parseJSON(result);
							var obj = result;
							if(obj.status=="n"){
								alert("用户名密码错误");
							}else{
								var url = obj.url;
								location.href=url;
							}
						},
						error:function(message){
							loading.result(message||'登录失败');
							isSubmiting = false;
						}
					});
				}
			}.bind(this),false);
			[userName,password].forEach(function(item){
				item.addEventListener('input',function(e){
					item.classList.remove('z-err');
				}.bind(this),false);
			}.bind(this));
		},
		check:function(){
			var result = true;
			[
				[userName,function(value){return value == ''}],
				[password,function(value){return value == ''}]
			].forEach(function(item){
				var value = item[0].value.trim();
				if(item[1](value)){
					item[0].classList.add('z-err');
					result = false;
				}
				item[0].value = value;
			});
			return result;
		}
	};
	page.init();
})(window,document);