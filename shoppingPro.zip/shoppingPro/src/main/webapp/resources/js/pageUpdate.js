(function(w,d,u){
	var loadForm = util.get('loadform');
	if(!loadForm){
		return;
	}
	var goodName = loadForm['title'];
	var introduce = loadForm['summary'];
	var picture = loadForm['image'];
	var type = loadForm['type'];
	var price = loadForm['price'];
	var text = loadForm['detail'];
	var isSubmiting = false;
	var loading = new Loading();
	var page = {
		init:function(){
			loadForm.addEventListener('submit',function(e){
				if(!isSubmiting){
					var name = goodName.value;
					var goodIntro = introduce.value;
					var goodPic = picture.value;
					var goodType = type.value;
					var goodPrice = price.value;
					var goodText = text.value;
					isSubmiting = true;
					loading.show();
					var requestData = {goodName:name,intro:goodIntro,pic:goodPic,
							type:goodType,price:goodPrice,detail:goodText};
					$.ajax({
						url:'addGoodToDB',
						type:'post',  
						dataType:'json',
						contentType:'application/json;charset=utf-8',
		                data:JSON.stringify(requestData),
						success:function(result){
							loading.hide();
							var obj = result;
							if(obj.status=="n"){
								alert("发布失败，重新发布");
							}else{
								alert("发布成功");
								location.href=obj.url;
							}
						},
						error:function(message){
							loading.result(message||'发布商品失败');
							isSubmiting = false;
						}
					});
				}
			}.bind(this),false);
		}
	};
	page.init();
})(window,document);